package pkg;
import java.util.concurrent.Semaphore;

import static pkg.Main.*;

public class Consumer extends Thread {
    private static int id;

    public Consumer(int id){
        this.id = id;
    }

    @Override
    public void run() {
        while(true){
            if(itemsInStorage >= maxStorageSpace){
                try {
                    semaphore.acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            while(itemsInStorage > 0){
                consumeItem();
                System.out.println("Consumer #"+this.id +" consumed item, item count now:" + itemsInStorage);
            }
            semaphore.release();
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
}

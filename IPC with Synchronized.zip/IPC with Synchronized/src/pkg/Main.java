package pkg;

import pkg.Consumer;
import pkg.Producer;

public class Main {
    static int itemsInStorage= 4;
    static final int maxStorageSpace= 8;
    static final int maxThreads = 2;

    public static void main(String[] args) {
        int producerIdCounter= 0;
        int consumerIdCounter= 0;
        Thread[] threads= new Thread[maxThreads] ;
        for(int i = 0;i < threads.length; i++){
            if(i%2!=0){
                threads[i] = new Producer(producerIdCounter);
                producerIdCounter++;
            }
            else{
                threads[i] = new Consumer(consumerIdCounter);
                consumerIdCounter++;
            }
        }

        for(Thread t : threads){
            t.start();
        }
    }

    static void produceNewItem(){
        itemsInStorage++;
    }

    static void consumeItem(){
        itemsInStorage--;
    }
}

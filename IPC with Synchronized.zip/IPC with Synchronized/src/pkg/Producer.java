package pkg;
import static pkg.Main.*;

public class Producer extends Thread {
    private static int id;

    public Producer(int id){
        this.id = id;
    }

    @Override
    public synchronized void run() {
        while(true){
            if(itemsInStorage == maxStorageSpace){
                try {
                    System.out.println("Producer #"+this.id+" sleeps");
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            else{
                produceNewItem();
                System.out.println("Producer #"+this.id+" produced item, item count now:" + itemsInStorage);
                if(itemsInStorage == 1){
                    notify();
                }
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

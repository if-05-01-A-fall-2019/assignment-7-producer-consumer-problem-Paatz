package pkg;
import static pkg.Main.*;

public class Consumer extends Thread {
    private static int id;

    public Consumer(int id){
        this.id = id;
    }

    @Override
    public void run() {
        while(true){
            if(itemsInStorage == 0){
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            else{
                consumeItem();
                System.out.println("Consumer #"+this.id +" consumed item, item count now:" + itemsInStorage);
                if(itemsInStorage == maxStorageSpace-1){
                    notify();
                }
            }
        }
    }
}
